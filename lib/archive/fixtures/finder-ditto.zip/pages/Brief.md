SITUATION BRIEF

Purpose:	brief the agent.
